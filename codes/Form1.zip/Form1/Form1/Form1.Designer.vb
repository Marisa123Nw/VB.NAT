﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ID = New System.Windows.Forms.TextBox()
        Me.รหัสนักศึกษา = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.stName = New System.Windows.Forms.TextBox()
        Me.lastname = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ID
        '
        Me.ID.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.ID.Location = New System.Drawing.Point(87, 25)
        Me.ID.Name = "ID"
        Me.ID.Size = New System.Drawing.Size(174, 20)
        Me.ID.TabIndex = 0
        '
        'รหัสนักศึกษา
        '
        Me.รหัสนักศึกษา.AutoSize = True
        Me.รหัสนักศึกษา.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.รหัสนักศึกษา.Location = New System.Drawing.Point(12, 28)
        Me.รหัสนักศึกษา.Name = "รหัสนักศึกษา"
        Me.รหัสนักศึกษา.Size = New System.Drawing.Size(69, 13)
        Me.รหัสนักศึกษา.TabIndex = 1
        Me.รหัสนักศึกษา.Text = "รหัสนักศึกษา"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label1.Location = New System.Drawing.Point(12, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(20, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ชื่อ"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label2.Location = New System.Drawing.Point(12, 90)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "นามสกุล"
        '
        'stName
        '
        Me.stName.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.stName.Location = New System.Drawing.Point(87, 54)
        Me.stName.Name = "stName"
        Me.stName.Size = New System.Drawing.Size(195, 20)
        Me.stName.TabIndex = 4
        '
        'lastname
        '
        Me.lastname.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lastname.Location = New System.Drawing.Point(87, 87)
        Me.lastname.Name = "lastname"
        Me.lastname.Size = New System.Drawing.Size(230, 20)
        Me.lastname.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LemonChiffon
        Me.Button1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button1.Location = New System.Drawing.Point(62, 151)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 37)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "แสดงข้อมูล"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.LemonChiffon
        Me.Button2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button2.Location = New System.Drawing.Point(326, 151)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 37)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "ok"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.LemonChiffon
        Me.Button3.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Button3.Location = New System.Drawing.Point(179, 151)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(103, 37)
        Me.Button3.TabIndex = 8
        Me.Button3.Text = "ใส่ค่าอัตโนมัติ"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(435, 301)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lastname)
        Me.Controls.Add(Me.stName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.รหัสนักศึกษา)
        Me.Controls.Add(Me.ID)
        Me.Name = "Form1"
        Me.Text = "ประวัตินักศึกษา"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ID As System.Windows.Forms.TextBox
    Friend WithEvents รหัสนักศึกษา As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents stName As System.Windows.Forms.TextBox
    Friend WithEvents lastname As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
