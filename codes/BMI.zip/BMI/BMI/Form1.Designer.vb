﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.weight = New System.Windows.Forms.TextBox()
        Me.height = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BMI = New System.Windows.Forms.Label()
        Me.result = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.suggest = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(51, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "น้ำหนัก(กิโลกรัม)"
        '
        'weight
        '
        Me.weight.Location = New System.Drawing.Point(52, 70)
        Me.weight.Name = "weight"
        Me.weight.Size = New System.Drawing.Size(104, 20)
        Me.weight.TabIndex = 1
        '
        'height
        '
        Me.height.Location = New System.Drawing.Point(265, 70)
        Me.height.Name = "height"
        Me.height.Size = New System.Drawing.Size(104, 20)
        Me.height.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(262, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "ส่วนสูง(เซนติเมตร)"
        '
        'BMI
        '
        Me.BMI.AutoSize = True
        Me.BMI.Location = New System.Drawing.Point(59, 124)
        Me.BMI.Name = "BMI"
        Me.BMI.Size = New System.Drawing.Size(41, 13)
        Me.BMI.TabIndex = 4
        Me.BMI.Text = "ค่า BMI"
        '
        'result
        '
        Me.result.AutoSize = True
        Me.result.Location = New System.Drawing.Point(47, 171)
        Me.result.Name = "result"
        Me.result.Size = New System.Drawing.Size(66, 13)
        Me.result.TabIndex = 5
        Me.result.Text = "แปลงผลลัพธ์"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(245, 98)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 52)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "คำนวณ"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'suggest
        '
        Me.suggest.Location = New System.Drawing.Point(45, 187)
        Me.suggest.Name = "suggest"
        Me.suggest.Size = New System.Drawing.Size(292, 113)
        Me.suggest.TabIndex = 7
        Me.suggest.Text = ""
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 347)
        Me.Controls.Add(Me.suggest)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.result)
        Me.Controls.Add(Me.BMI)
        Me.Controls.Add(Me.height)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.weight)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents weight As System.Windows.Forms.TextBox
    Friend WithEvents height As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents BMI As System.Windows.Forms.Label
    Friend WithEvents result As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents suggest As System.Windows.Forms.RichTextBox

End Class
