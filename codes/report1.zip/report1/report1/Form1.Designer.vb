﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.student_id = New System.Windows.Forms.Label()
        Me.student_Name = New System.Windows.Forms.Label()
        Me.email = New System.Windows.Forms.Label()
        Me.student_age = New System.Windows.Forms.Label()
        Me.student_enrol = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(30, 30)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(124, 34)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "รายงานข้อมูลนักศึกษา"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'student_id
        '
        Me.student_id.AutoSize = True
        Me.student_id.Location = New System.Drawing.Point(34, 88)
        Me.student_id.Name = "student_id"
        Me.student_id.Size = New System.Drawing.Size(69, 13)
        Me.student_id.TabIndex = 1
        Me.student_id.Text = "รหัสนักศึกษา"
        '
        'student_Name
        '
        Me.student_Name.AutoSize = True
        Me.student_Name.Location = New System.Drawing.Point(34, 114)
        Me.student_Name.Name = "student_Name"
        Me.student_Name.Size = New System.Drawing.Size(63, 13)
        Me.student_Name.TabIndex = 2
        Me.student_Name.Text = "ชื่อนักศึกษา"
        '
        'email
        '
        Me.email.AutoSize = True
        Me.email.Location = New System.Drawing.Point(34, 140)
        Me.email.Name = "email"
        Me.email.Size = New System.Drawing.Size(74, 13)
        Me.email.TabIndex = 3
        Me.email.Text = "อีเมลนักศึกษา"
        '
        'student_age
        '
        Me.student_age.AutoSize = True
        Me.student_age.Location = New System.Drawing.Point(35, 175)
        Me.student_age.Name = "student_age"
        Me.student_age.Size = New System.Drawing.Size(68, 13)
        Me.student_age.TabIndex = 4
        Me.student_age.Text = "อายุนักศึกษา"
        '
        'student_enrol
        '
        Me.student_enrol.AutoSize = True
        Me.student_enrol.Location = New System.Drawing.Point(40, 198)
        Me.student_enrol.Name = "student_enrol"
        Me.student_enrol.Size = New System.Drawing.Size(134, 13)
        Me.student_enrol.TabIndex = 5
        Me.student_enrol.Text = "ค่าลงทะเบียนตลอดหลักสูตร"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.student_enrol)
        Me.Controls.Add(Me.student_age)
        Me.Controls.Add(Me.email)
        Me.Controls.Add(Me.student_Name)
        Me.Controls.Add(Me.student_id)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents student_id As System.Windows.Forms.Label
    Friend WithEvents student_Name As System.Windows.Forms.Label
    Friend WithEvents email As System.Windows.Forms.Label
    Friend WithEvents student_age As System.Windows.Forms.Label
    Friend WithEvents student_enrol As System.Windows.Forms.Label

End Class
