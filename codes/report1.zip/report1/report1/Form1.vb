﻿Option Explicit Off
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        student_id.Text = "634272123"
        student_Name.Text = "Marisa"
        email.Text = "Marisa.lam@mail.pbru.ac.th"

        Dim birthdate As Date = #10/1/2002#
        REM Dim age As Integer

        age = Year(Today()) - Year(birthdate)
        student_age.Text = age.ToString & "เกิดวัน" & birthdate.ToString("dddd")
        student_enrol.Text = (16000 * 8).ToString("n")
    End Sub
End Class
