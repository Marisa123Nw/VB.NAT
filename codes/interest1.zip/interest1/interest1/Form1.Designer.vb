﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.deposit = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.interest = New System.Windows.Forms.TextBox()
        Me.detail = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "จำนวนเงินต้น"
        '
        'deposit
        '
        Me.deposit.Location = New System.Drawing.Point(12, 38)
        Me.deposit.Name = "deposit"
        Me.deposit.Size = New System.Drawing.Size(100, 20)
        Me.deposit.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "อัตราดอกเบี้ย"
        '
        'interest
        '
        Me.interest.Location = New System.Drawing.Point(12, 98)
        Me.interest.Name = "interest"
        Me.interest.Size = New System.Drawing.Size(100, 20)
        Me.interest.TabIndex = 3
        '
        'detail
        '
        Me.detail.Location = New System.Drawing.Point(12, 124)
        Me.detail.Name = "detail"
        Me.detail.Size = New System.Drawing.Size(346, 178)
        Me.detail.TabIndex = 4
        Me.detail.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(210, 63)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(148, 51)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "คำนวนดอกเบี้ยทบต้น"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(410, 314)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.detail)
        Me.Controls.Add(Me.interest)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.deposit)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents deposit As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents interest As System.Windows.Forms.TextBox
    Friend WithEvents detail As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
